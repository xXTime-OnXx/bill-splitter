create function uuid_ns_url() returns uuid
    immutable
    strict
    parallel safe
    language c
as
$$uuid_ns_url$$;

alter function uuid_ns_url() owner to "bill-splitter";


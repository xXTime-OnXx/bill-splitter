create function uuid_generate_v3(namespace uuid, name text) returns uuid
    immutable
    strict
    parallel safe
    language c
as
$$uuid_generate_v3$$;

alter function uuid_generate_v3(uuid, text) owner to "bill-splitter";

